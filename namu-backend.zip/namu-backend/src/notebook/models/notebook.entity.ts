import { Column, Entity, PrimaryGeneratedColumn, Timestamp } from 'typeorm';

@Entity()
export class Notebook {
  @PrimaryGeneratedColumn()
  notebookId: number;

  @Column()
  name: string;

  @Column()
  namespace: string;

  @Column()
  title: string;

  @Column()
  image: string;

  @Column()
  cpu: string;

  @Column()
  memory: string;

  @Column()
  gpus: string;

  @Column()
  workspaceName: string;

  @Column()
  size: string;

  @Column()
  projectId: string;

  @Column()
  projectName: string;

  @Column()
  gpuTime: string;

  @Column()
  status: string;

  @Column()
  createdAt: Date;
}
