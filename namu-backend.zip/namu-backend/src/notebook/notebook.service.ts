import { HttpService, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { Repository } from 'typeorm';
import { Notebook } from './models/notebook.entity';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class NotebookService {
  constructor(
    @InjectRepository(Notebook)
    private notebookRepository: Repository<Notebook>,
    private httpService: HttpService,
  ) {}

  create(notebook: Notebook): Promise<Notebook> {
    const headersRequest = {
      'Content-Type': 'application/json',
      Cookie: `authservice_session=MTYyMzIxNjY4MXxOd3dBTkV0V1drSTBUelJZUTBVM1EwMDJSa3hQVDA4MFFUUlJUalpOUWtSTFVFNUdTVVl6UTFaR1VWQXlXRXBQVUVsVlNGcEtORUU9fCw_DdzIayiBrVkqxlfyc1zgKj4aEqk2HW4dG21NOiUT`,
    };

    const data = JSON.stringify({
      name: notebook.name,
      namespace: 'admin',
      image:
        'gcr.io/kubeflow-images-public/tensorflow-1.15.2-notebook-cpu:1.0.0',
      customImage: '',
      customImageCheck: false,
      cpu: '0.5',
      memory: '1.0Gi',
      gpus: {
        num: 'none',
      },
      noWorkspace: false,
      workspace: {
        type: 'New',
        name: notebook.workspaceName,
        templatedName: 'workspace-{notebook-name}',
        size: '10Gi',
        mode: 'ReadWriteOnce',
        class: '{none}',
        extraFields: {},
      },
      datavols: [],
      shm: true,
      configurations: [],
      affinityConfig: 'none',
      tolerationGroup: 'none',
    });
    this.httpService
      .post(
        'http://118.67.133.163:31380/jupyter/api/namespaces/admin/notebooks',
        data,
        { headers: headersRequest },
      )
      .subscribe((res) => console.log(res));
    return this.notebookRepository.save(notebook);
  }

  private getPath(url: string): string {
    const path = this.httpService
      .get('http://118.67.133.163:31380/')
      .subscribe((res) => {
        return res.request.path;
      });
    return path.toString();
  }
  async getAll(): Promise<Notebook[]> {
    const path = this.getPath('http://118.67.133.163:31380');
    console.log(path);
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };
    const data = JSON.stringify({
      login: 'admin@kubeflow.org',
      password: '12341234',
    });
    const cookie = this.httpService
      .post(`http://118.67.133.163:31380/`, data, { headers: headers })
      .subscribe((res) => {
        return res.data;
      });
    const headersRequest = {
      Cookie: `authservice_session=MTYyMzIxNjY4MXxOd3dBTkV0V1drSTBUelJZUTBVM1EwMDJSa3hQVDA4MFFUUlJUalpOUWtSTFVFNUdTVVl6UTFaR1VWQXlXRXBQVUVsVlNGcEtORUU9fCw_DdzIayiBrVkqxlfyc1zgKj4aEqk2HW4dG21NOiUT`,
    };

    this.httpService
      .get(
        'http://118.67.133.163:31380/jupyter/api/namespaces/admin/notebooks',
        { headers: headersRequest },
      )
      .subscribe((res) => {
        return res.data;
      });
    return this.notebookRepository.find();
  }
}
