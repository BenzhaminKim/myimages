import { Body, Controller, Post, Get } from '@nestjs/common';
import { NotebookService } from './notebook.service';
import { Notebook } from './models/notebook.entity';

@Controller('notebook')
export class NotebookController {
  constructor(private notebookService: NotebookService) {}

  @Post()
  async create(@Body() notebook: Notebook): Promise<Notebook> {
    return this.notebookService.create(notebook);
  }

  @Get()
  async getAll(): Promise<Notebook[]> {
    return this.notebookService.getAll();
  }
}
