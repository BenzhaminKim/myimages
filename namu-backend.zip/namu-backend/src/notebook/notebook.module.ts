import { HttpModule, Module } from '@nestjs/common';
import { NotebookService } from './notebook.service';
import { NotebookController } from './notebook.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Notebook } from './models/notebook.entity';

@Module({
  imports: [HttpModule, TypeOrmModule.forFeature([Notebook])],
  providers: [NotebookService],
  controllers: [NotebookController],
})
export class NotebookModule {}
